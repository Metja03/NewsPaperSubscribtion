public abstract class NewspaperSubscription {
    private String subscriberName;
    String address;
    double rate;

    public NewspaperSubscription(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public String getAddress() {
        return address;
    }

    public abstract void setAddress(String address);

    public double getRate() {
        return rate;
    }
    
    public static void main(String[] args) {
        DemoSubscriptions.main(args);
    }
    
}
