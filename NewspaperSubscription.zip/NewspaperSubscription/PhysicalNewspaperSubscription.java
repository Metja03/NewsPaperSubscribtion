public class PhysicalNewspaperSubscription extends NewspaperSubscription {

    public PhysicalNewspaperSubscription(String subscriberName) {
        super(subscriberName);
    }

    @Override
    public void setAddress(String address) {
        boolean hasDigit = false;
        for (char c : address.toCharArray()) {
            if (Character.isDigit(c)) {
                hasDigit = true;
                break;
            }
        }
        if (hasDigit) {
            this.address = address;
            this.rate = 15;
        } else {
            System.out.println("Error: Address must contain at least one digit.");
            this.rate = 0;
        }
    }
}

