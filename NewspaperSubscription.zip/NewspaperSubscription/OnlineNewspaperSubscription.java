public class OnlineNewspaperSubscription extends NewspaperSubscription {
    public OnlineNewspaperSubscription(String subscriberName) {
        super(subscriberName);
    }

    @Override
    public void setAddress(String address) {
        if (address.contains("@")) {
            this.address = address;
            this.rate = 9;
        } else {
            System.out.println("Error: Invalid address. Subscription rate set to 0.");
            this.rate = 0;
        }
    }
}
