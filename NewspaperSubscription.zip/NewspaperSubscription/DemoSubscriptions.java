public class DemoSubscriptions {
    public static void main(String[] args) {
        NewspaperSubscription[] subscriptions = new NewspaperSubscription[6];

        subscriptions[0] = new PhysicalNewspaperSubscription("Spice");
        subscriptions[0].setAddress("123 Main St.");

        subscriptions[1] = new PhysicalNewspaperSubscription("Charmaine");
        subscriptions[1].setAddress("456 Elm St.");

        subscriptions[2] = new OnlineNewspaperSubscription("Tebello Malatole");
        subscriptions[2].setAddress("tebello@gmail.com");

        subscriptions[3] = new OnlineNewspaperSubscription("Alice Davis");
        subscriptions[3].setAddress("alice_davis@example.com");
        
        subscriptions[4] = new PhysicalNewspaperSubscription("Akhona");
        subscriptions[4].setAddress("akhona@gmail.com");
        
        
        subscriptions[5] = new OnlineNewspaperSubscription("Jane Doe");
        subscriptions[5].setAddress("Ngubane street"); 
        

        for (NewspaperSubscription subscription : subscriptions) {
            System.out.println("Subscriber Name: " + subscription.getSubscriberName());
            System.out.println("Address: " + subscription.getAddress());
            System.out.println("Subscription Rate: $" + subscription.getRate());
            System.out.println();
        }
    }
}

